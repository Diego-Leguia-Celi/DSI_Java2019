 <table>
 <th>Nombre</th>
 <th>Direccion</th>
 <th>Teléfono</th>
 <th>Observacion</th>
 <th>Editar</th>
 <th>Eliminar</th>

<?php 

$agenda = ubigeo::ningunDato();

$datos = $agenda->select();

while ($row = $datos->fetch_array()) {
	
	echo '<tr>';
	echo '<td>',$row['nombre'] ,'</td>';
	echo '<td>',$row['direccion'] ,'</td>';
	echo '<td>',$row['telefono'] ,'</td>';
	echo '<td>',$row['observacion'] ,'</td>';
	echo "<td> <a href=\"index.php?accion=editar&&id=$row[id]\">Editar</a> </td>";
	echo "<td> <a href=\"index.php?accion=eliminar&&id=$row[id]\">Eliminar</a> </td>";

	echo '</tr>';
}


 ?>

</table>