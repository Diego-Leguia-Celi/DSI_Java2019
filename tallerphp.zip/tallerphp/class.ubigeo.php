
<?php 
	include 'config/class.conexion.php';
class ubigeo{

	protected $nombre;
	protected $direccion;
	protected $telefono;
	protected $observacion;
	protected $id;

	public function __construct($nom, $dir, $tel, $obs, $id = ''){
		$db = new Conexion();

		$this->nombre= $nom;
		$this->direccion = $dir;
		$this->telefono = $tel;
		$this->observacion = $obs;
		$this->id = $id;
	}

	static function ningunDato(){
		return new self('', '', '', '', '');
	} 


	static function soloId($id){
		return new self('','','','', $id);
	}

	public function insert(){

		$db = new Conexion();

		$sql = "INSERT INTO `contactos`(`nombre`, `direccion`, `telefono`, `observacion`) VALUES ('$this->nombre', '$this->direccion', '$this->telefono', '$this->observacion')";

		$db->query($sql) ? header("location: index.php?res=insertado") : header("location: index.php?res=error");
	}


	public function update(){

		$db = new Conexion();

		$sql = "UPDATE `contactos` SET `nombre`='$this->nombre',`direccion`='$this->direccion',`telefono`=$this->telefono,`observacion`='$this->observacion' WHERE `id` = $this->id";
		
		$db->query($sql) ? header("location: index.php?res=editado") : header("location: index.php?res=error");
	}



	public function selectId(){
		$db = new Conexion();

		$sql = "SELECT * FROM `contactos` WHERE `id` = $this->id";

		$result = $db->query($sql);

		return $result;
	}

	public function select(){

		$db = new Conexion();

		$sql = "SELECT * FROM `contactos`";

		$result = $db->query($sql);
	return $result;
	}
	}
 ?>

 