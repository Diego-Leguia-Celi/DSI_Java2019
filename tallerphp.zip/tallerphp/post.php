<?php 
include 'class.ubigeo.php';

if (isset($_POST['submit'])) {
	
	if ($_POST['accion'] == 'insert') {
		
		$nom = $_POST['nombre'];
		$dir = $_POST['direccion'];
		$tel = $_POST['telefono'];
		$obs = $_POST['observacion'];

		$agenda = new ubigeo($nom, $dir, $tel, $obs);
		$agenda->insert();

	}

	if ($_POST['accion'] == 'update') {	
			$nom = $_POST['nombre'];
			$dir = $_POST['direccion'];
			$tel = $_POST['telefono'];
			$obs = $_POST['observacion'];
			$id = $_POST['id'];

			$agenda = new ubigeo($nom, $dir, $tel, $obs, $id);
			$agenda->update();
		}
	}
 ?>