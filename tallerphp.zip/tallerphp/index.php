
<?php 
include 'class.ubigeo.php';
$datos = array('nombre'=>'', 'direccion'=>'', 'telefono'=>'', 'observacion'=>'observacion', 'id'=>'');
$accion = 'insert';
include 'get.php';

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Contactos</title>
	
</head>
<body>


<form action="post.php" method="post">

	<div class="icon-user-plus"></div>

	<input type="text" name="nombre" value="<?php echo $datos['nombre']; ?>" placeholder="Nombre" required="requiered">

	<input type="text" name="direccion" value="<?php echo $datos['direccion']; ?>" placeholder="direccion" required="requiered">

	<input type="text" name="telefono"  value="<?php echo $datos['telefono']; ?>" placeholder="Teléfono" required="requiered">

	<input type="text" name="observacion"  value="<?php echo $datos['observacion']; ?>" placeholder="obs">

	
	<input type="hidden" name="id" value="<?php  echo $datos['id']?>">
	<input type="hidden" name="accion" value="<?php  echo $accion?>">
	<input type="submit" name="submit" value="Registrar">
</form>

<?php include 'tabla.php';?>
</body>
</html> 